package com.s13sh.white_bus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhiteBusApplicationTests {

	@Test
	void contextLoads() {
	}

}
