package com.s13sh.white_bus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhiteBusApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhiteBusApplication.class, args);
	}

}